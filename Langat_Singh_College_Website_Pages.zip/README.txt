LANGAT SINGH COLLEGE WEBSITE - UPDATED PAGES

Files included:
- index.html
- about.html
- courses.html
- admission.html
- notices.html
- payment.html (your existing payment page can be copied here)
- gallery.html
- faculty.html
- contact.html
- css/pages.css

INSTALL:
1. Open your existing "College Website" folder in VS Code.
2. Copy these HTML files into the root of that folder.
3. Copy pages.css into your existing css folder.
4. Keep your existing style.css.
5. Keep your existing payment.html if you already added it.
6. Open index.html with Live Server.

IMPORTANT:
- The pages use official college information where available.
- Notice items should be verified on the official notice board before being treated as final.
- Do not add fake notices, fake staff details, or fake payment gateways.
